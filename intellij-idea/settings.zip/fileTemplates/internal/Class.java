#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import lombok.extern.log4j.Log4j2;
#parse("File Header.java")
public class ${NAME} {



}
